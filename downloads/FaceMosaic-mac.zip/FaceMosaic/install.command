#!/bin/bash
# FaceMosaic installer for macOS + DaVinci Resolve Studio.
# Double-click (first time: right-click > Open), or run:  bash install.command
set -e
cd "$(dirname "$0")"

DEST="$HOME/FaceMosaic"
RESOLVE_SCRIPTS="$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility"

echo "Installing FaceMosaic into $DEST"
echo

# 1. Python. Release builds ship a pinned Python (the compiled engine needs that exact version).
PY=""
if [ -f app/PYTHON_URL ]; then
  PY_URL="$(cat app/PYTHON_URL)"
  PY_STAMP="$DEST/python/.source"
  if [ ! -x "$DEST/python/bin/python3" ] || [ "$(cat "$PY_STAMP" 2>/dev/null)" != "$PY_URL" ]; then
    echo "Downloading Python runtime (one time, ~20 MB)..."
    mkdir -p "$DEST"; rm -rf "$DEST/python"
    curl -fsSL "$PY_URL" -o "$DEST/python.tgz" || { echo "Download failed — check your internet connection."; read -n 1 -s -r -p "Press any key to close"; exit 1; }
    tar -xzf "$DEST/python.tgz" -C "$DEST" && rm -f "$DEST/python.tgz"
    echo "$PY_URL" > "$PY_STAMP"
    rm -rf "$DEST/venv"                       # rebuild against the new runtime
  fi
  PY="$DEST/python/bin/python3"
fi
[ -n "$PY" ] || for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  echo "Python 3 is needed. macOS will offer to install the Command Line Tools now —"
  echo "click Install, wait for it to finish, then run this installer again."
  xcode-select --install 2>/dev/null || true
  read -n 1 -s -r -p "Press any key to close"; exit 1
fi
echo "Using $("$PY" --version) at $PY"

# 2. files
mkdir -p "$DEST/app" "$DEST/people" "$DEST/jobs"
# keep already-downloaded models when updating
[ -d "$DEST/app/models" ] && mv "$DEST/app/models" "$DEST/.models-keep"
rm -rf "$DEST/app"
cp -R app "$DEST/app"
[ -d "$DEST/.models-keep" ] && rm -rf "$DEST/app/models" && mv "$DEST/.models-keep" "$DEST/app/models"
xattr -dr com.apple.quarantine "$DEST/app" 2>/dev/null || true

# models (downloaded once from OpenCV Zoo)
MODELS="$DEST/app/models"; mkdir -p "$MODELS"
get_model() {  # name, path-in-zoo, min-bytes
  local f="$MODELS/$1"
  if [ -f "$f" ] && [ "$(stat -f%z "$f" 2>/dev/null || stat -c%s "$f")" -ge "$3" ]; then return 0; fi
  echo "Downloading $1 ..."
  for base in "https://media.githubusercontent.com/media/opencv/opencv_zoo/main" \
              "https://huggingface.co/opencv/$4/resolve/main"; do
    local url="$base/$2"; [ "$base" != "${base#https://huggingface}" ] && url="$base/$1"
    if curl -fsSL -o "$f.part" "$url" && [ "$(stat -f%z "$f.part" 2>/dev/null || stat -c%s "$f.part")" -ge "$3" ]; then
      mv "$f.part" "$f"; return 0
    fi
  done
  rm -f "$f.part"; echo "Could not download $1 — check your internet connection and run the installer again."
  read -n 1 -s -r -p "Press any key to close"; exit 1
}
get_model face_detection_yunet_2023mar.onnx models/face_detection_yunet/face_detection_yunet_2023mar.onnx 200000 face_detection_yunet
get_model face_recognition_sface_2021dec.onnx models/face_recognition_sface/face_recognition_sface_2021dec.onnx 30000000 face_recognition_sface

# 3. private Python environment with OpenCV + ffmpeg
if [ ! -x "$DEST/venv/bin/python3" ]; then
  "$PY" -m venv "$DEST/venv"
fi
"$DEST/venv/bin/python3" -m pip install --quiet --upgrade pip
"$DEST/venv/bin/python3" -m pip install --quiet -r requirements.txt
echo "Python packages installed."

# 4. Resolve menu scripts (Workspace > Scripts)
mkdir -p "$RESOLVE_SCRIPTS"
rm -f "$RESOLVE_SCRIPTS"/FaceMosaic\ -\ *.lua
cp resolve/*.lua "$RESOLVE_SCRIPTS/"
echo "Resolve scripts installed."

# 5. self-test
"$DEST/venv/bin/python3" "$DEST/app/facemosaic.py" people

if ! command -v ffprobe >/dev/null 2>&1 && [ ! -x /opt/homebrew/bin/ffprobe ] && [ ! -x /usr/local/bin/ffprobe ]; then
  echo
  echo "Tip (optional): 'brew install ffmpeg' gives the most accurate frame-rate and timecode detection."
fi

echo
echo "Done. Restart DaVinci Resolve, then look under Workspace > Scripts for:"
echo "  • FaceMosaic - Add Person From Selected Clip"
echo "  • FaceMosaic - Open People Folder"
echo "  • FaceMosaic - Process Selected Clips"
echo "  • FaceMosaic - Import Results"
echo "  • FaceMosaic - License"
echo
read -n 1 -s -r -p "Press any key to close" || true
echo
