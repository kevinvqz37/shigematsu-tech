-- FaceMosaic: open the folder of people kept visible.
-- One sub-folder per person (e.g. "Kevin", "Saki"), each with a few clear photos of their face.
-- Different angles, lighting, glasses/no glasses and hats all help.
local dir = os.getenv("HOME") .. "/FaceMosaic/people"
local r = dir:gsub("'", "'\\''")
os.execute("mkdir -p '" .. r .. "' && open '" .. r .. "'")
