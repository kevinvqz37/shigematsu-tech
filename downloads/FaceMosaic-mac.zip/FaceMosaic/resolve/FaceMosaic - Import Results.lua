-- FaceMosaic: bring finished mosaic clips into the project.
-- Imports them into a "FaceMosaic" bin (or swaps the originals, if you chose that),
-- and adds markers where a quick check is worth it:
--   Red    = a face was LEFT VISIBLE but the match was borderline — make sure it's really you/family
--   Yellow = a face was mosaicked but looked a bit like someone you kept

local HOME = os.getenv("HOME")
local BASE = HOME .. "/FaceMosaic"

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local function q(s)
  local r = tostring(s):gsub("'", "'\\''")
  return "'" .. r .. "'"
end

-- Resolve returns selections as {clip=index} or {index=clip} depending on version; accept both.
local function clips_in(t)
  local out = {}
  for k, v in pairs(t or {}) do
    local c = (type(v) == "userdata" or type(v) == "table") and v or ((type(k) == "userdata" or type(k) == "table") and k or nil)
    if c then out[#out + 1] = c end
  end
  return out
end

local function exists(p)
  local f = io.open(p, "r")
  if f then f:close() return true end
  return false
end

local function read_lines(p)
  local t = {}
  local f = io.open(p, "r")
  if not f then return t end
  for line in f:lines() do
    if line ~= "" then t[#t + 1] = line end
  end
  f:close()
  return t
end

local function split_tabs(s)
  local t = {}
  for field in (s .. "\t"):gmatch("(.-)\t") do t[#t + 1] = field end
  return t
end

local function message(title, text)
  local win = disp:AddWindow({ ID = "FMMsg", WindowTitle = title, Geometry = { 300, 300, 500, 200 } },
    ui:VGroup{
      ui:Label{ Text = text, WordWrap = true },
      ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } },
    })
  function win.On.OK.Clicked(ev) disp:ExitLoop() end
  function win.On.FMMsg.Close(ev) disp:ExitLoop() end
  win:Show(); disp:RunLoop(); win:Hide()
end

local project = resolve:GetProjectManager():GetCurrentProject()
if not project then
  message("FaceMosaic", "Open a project first.")
  return
end
local mp = project:GetMediaPool()

-- ---------------------------------------------------------------- find jobs
local ready, running = {}, 0
local lf = io.popen("ls -1 " .. q(BASE .. "/jobs") .. " 2>/dev/null | sort")
if lf then
  for name in lf:lines() do
    local dir = BASE .. "/jobs/" .. name
    if not exists(dir .. "/imported.flag") then
      if exists(dir .. "/done.flag") then
        if exists(dir .. "/results.tsv") then ready[#ready + 1] = dir end
      elseif exists(dir .. "/clips.txt") then
        running = running + 1
      end
    end
  end
  lf:close()
end

if #ready == 0 then
  if running > 0 then
    message("FaceMosaic", "Still working on " .. running .. " job(s). Check the Terminal window and run this again when it says All done.")
  else
    message("FaceMosaic", "Nothing new to import.")
  end
  return
end

-- ---------------------------------------------------------------- media pool index
local by_path = {}
local function walk(folder)
  for _, c in ipairs(clips_in(folder:GetClipList())) do
    local p = c:GetClipProperty("File Path")
    if p and p ~= "" then by_path[p] = c end
  end
  for _, sub in ipairs(clips_in(folder:GetSubFolderList())) do walk(sub) end
end
walk(mp:GetRootFolder())

local function get_bin()
  local root = mp:GetRootFolder()
  for _, f in ipairs(clips_in(root:GetSubFolderList())) do
    if f:GetName() == "FaceMosaic" then return f end
  end
  return mp:AddSubFolder(root, "FaceMosaic")
end

-- ---------------------------------------------------------------- import
local imported, swapped, marked, problems = 0, 0, 0, {}
local prev_folder = mp:GetCurrentFolder()

for _, dir in ipairs(ready) do
  local replace = false
  for _, l in ipairs(read_lines(dir .. "/options.txt")) do
    if l == "replace=1" then replace = true end
  end

  local clips, marks = {}, {}
  for _, line in ipairs(read_lines(dir .. "/results.tsv")) do
    local f = split_tabs(line)
    if f[1] == "CLIP" then clips[#clips + 1] = { src = f[2], out = f[3] }
    elseif f[1] == "MARK" then
      marks[#marks + 1] = { out = f[2], frame = tonumber(f[3]), dur = tonumber(f[4]),
                            color = f[5], name = f[6], note = f[7] or "" }
    end
  end

  local item_for_out = {}
  local to_import = {}
  for _, c in ipairs(clips) do
    if by_path[c.out] then
      item_for_out[c.out] = by_path[c.out]
      pcall(function() by_path[c.out]:ReplaceClip(c.out) end)   -- re-read a re-rendered file
    elseif replace and by_path[c.src] then
      local item = by_path[c.src]
      if item:ReplaceClip(c.out) then
        item_for_out[c.out] = item
        by_path[c.out] = item
        swapped = swapped + 1
      else
        problems[#problems + 1] = "couldn't swap " .. c.src:match("([^/]+)$") .. " — imported it instead"
        to_import[#to_import + 1] = c.out
      end
    else
      to_import[#to_import + 1] = c.out
    end
  end

  if #to_import > 0 then
    mp:SetCurrentFolder(get_bin())
    local items = mp:ImportMedia(to_import) or {}
    for _, it in ipairs(clips_in(items)) do
      local p = it:GetClipProperty("File Path")
      item_for_out[p] = it
      by_path[p] = it
      imported = imported + 1
    end
  end

  for _, m in ipairs(marks) do
    local it = item_for_out[m.out]
    if it and m.frame then
      if it:AddMarker(m.frame, m.color, m.name, m.note, math.max(1, m.dur or 1)) then
        marked = marked + 1
      end
    end
  end

  local f = io.open(dir .. "/imported.flag", "w")
  if f then f:write(os.date("%Y-%m-%d %H:%M:%S")); f:close() end
end

if prev_folder then mp:SetCurrentFolder(prev_folder) end

local text = ""
if imported > 0 then text = text .. imported .. " clip(s) added to the FaceMosaic bin.\n" end
if swapped > 0 then text = text .. swapped .. " clip(s) swapped in place — your timelines now use the mosaic versions.\n" end
if imported == 0 and swapped == 0 then text = text .. "Those clips were already in the project.\n" end
if marked > 0 then
  text = text .. "\n" .. marked .. " marker(s) to check: RED = face left visible on a borderline match, YELLOW = possibly over-mosaicked."
else
  text = text .. "\nNo spots flagged for review."
end
if #problems > 0 then text = text .. "\n\n" .. table.concat(problems, "\n") end
message("FaceMosaic", text)
