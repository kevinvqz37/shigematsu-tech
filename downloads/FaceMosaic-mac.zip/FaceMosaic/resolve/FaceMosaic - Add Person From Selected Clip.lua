-- FaceMosaic: teach it a face to keep visible.
-- Select ONE clip where that person is the biggest face on screen (a selfie vlog shot is perfect),
-- enter their name, and it saves ~25 face photos into ~/FaceMosaic/people/<Name>/.
-- Check that folder afterwards and delete any photo that isn't them.

local HOME   = os.getenv("HOME")
local BASE   = HOME .. "/FaceMosaic"
local PY     = BASE .. "/venv/bin/python3"
local ENGINE = BASE .. "/app/facemosaic.py"

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local function q(s)
  local r = tostring(s):gsub("'", "'\\''")
  return "'" .. r .. "'"
end

-- Resolve returns selections as {clip=index} or {index=clip} depending on version; accept both.
local function clips_in(t)
  local out = {}
  for k, v in pairs(t or {}) do
    local c = (type(v) == "userdata" or type(v) == "table") and v or ((type(k) == "userdata" or type(k) == "table") and k or nil)
    if c then out[#out + 1] = c end
  end
  return out
end

local function exists(p)
  local f = io.open(p, "r")
  if f then f:close() return true end
  return false
end

local function message(title, text)
  local win = disp:AddWindow({ ID = "FMMsg", WindowTitle = title, Geometry = { 300, 300, 460, 170 } },
    ui:VGroup{
      ui:Label{ Text = text, WordWrap = true },
      ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } },
    })
  function win.On.OK.Clicked(ev) disp:ExitLoop() end
  function win.On.FMMsg.Close(ev) disp:ExitLoop() end
  win:Show(); disp:RunLoop(); win:Hide()
end

if not exists(PY) or not exists(ENGINE) then
  message("FaceMosaic", "FaceMosaic isn't installed yet. Run install.command first.")
  return
end
local project = resolve:GetProjectManager():GetCurrentProject()
if not project then message("FaceMosaic", "Open a project first.") return end
local mp = project:GetMediaPool()

-- ---------------------------------------------------------------- license
local BUY_URL = "https://buy.stripe.com/aFa7sL1yV31U5CVg8i9MY02"   -- set by the release build

local function run_engine(args)
  local h = io.popen(q(PY) .. " " .. q(ENGINE) .. " " .. args .. " 2>&1")
  local out = h and h:read("*a") or ""
  if h then h:close() end
  return out
end

local function ensure_license()
  local out = run_engine("license")
  if out:find("STATUS=ok", 1, true) then return true end
  local reason = out:match("STATUS=needed ([^\n]*)") or "FaceMosaic isn't activated on this Mac."
  while true do
    local lw = disp:AddWindow({ ID = "FMLic", WindowTitle = "FaceMosaic — License", Geometry = { 320, 260, 500, 210 } },
      ui:VGroup{
        ui:Label{ ID = "Msg", Text = reason, WordWrap = true, Weight = 0 },
        ui:HGroup{ Weight = 0,
          ui:Label{ Text = "License key:", Weight = 0 },
          ui:LineEdit{ ID = "Key", PlaceholderText = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX" },
        },
        ui:HGroup{ Weight = 0,
          ui:Button{ ID = "Buy", Text = "Buy a license" },
          ui:HGap(0, 1),
          ui:Button{ ID = "Cancel", Text = "Cancel" },
          ui:Button{ ID = "Activate", Text = "Activate" },
        },
      })
    local it = lw:GetItems()
    local choice = nil
    function lw.On.Activate.Clicked(ev) choice = "activate"; disp:ExitLoop() end
    function lw.On.Cancel.Clicked(ev) choice = "cancel"; disp:ExitLoop() end
    function lw.On.Buy.Clicked(ev) os.execute("open " .. q(BUY_URL)) end
    function lw.On.FMLic.Close(ev) choice = "cancel"; disp:ExitLoop() end
    lw:Show(); disp:RunLoop()
    local key = (it.Key.Text or ""):gsub("%s+", "")
    lw:Hide()
    if choice ~= "activate" then return false end
    if key ~= "" then
      local res = run_engine("license --activate " .. q(key))
      if res:find("Activated", 1, true) then
        message("FaceMosaic", res:match("(Activated[^\n]*)") or "Activated.")
        return true
      end
      reason = res:match("STATUS=needed ([^\n]*)") or "Activation failed."
    else
      reason = "Enter your license key."
    end
  end
end

if not ensure_license() then return end

local path
local ok, sel = pcall(function() return mp:GetSelectedClips() end)
if ok and sel then
  for _, clip in ipairs(clips_in(sel)) do
    local p = clip:GetClipProperty("File Path") or ""
    local t = clip:GetClipProperty("Type") or ""
    if p ~= "" and t:find("Video") then path = p break end
  end
end
if not path then
  message("FaceMosaic", "Select one video clip in the Media Pool where the person's face is big and clear, then run this again.")
  return
end

local win = disp:AddWindow({ ID = "FMAdd", WindowTitle = "FaceMosaic — Add Person", Geometry = { 300, 250, 460, 170 } },
  ui:VGroup{
    ui:Label{ Text = "From: " .. path:match("([^/]+)$"), WordWrap = true, Weight = 0 },
    ui:HGroup{ Weight = 0,
      ui:Label{ Text = "Name:", Weight = 0 },
      ui:LineEdit{ ID = "Name", PlaceholderText = "e.g. Kevin" },
    },
    ui:Label{ Text = "The biggest face in the clip is used. You'll check the photos afterwards.", WordWrap = true, Weight = 0 },
    ui:HGroup{ Weight = 0, ui:HGap(0, 1),
      ui:Button{ ID = "Cancel", Text = "Cancel" },
      ui:Button{ ID = "Go", Text = "Add" } },
  })
local items = win:GetItems()
local go = false
function win.On.Go.Clicked(ev) go = true; disp:ExitLoop() end
function win.On.Cancel.Clicked(ev) disp:ExitLoop() end
function win.On.FMAdd.Close(ev) disp:ExitLoop() end
win:Show(); disp:RunLoop()
local name = (items.Name.Text or ""):gsub("[/\\:\"'`$]", ""):gsub("^%s+", ""):gsub("%s+$", "")
win:Hide()
if not go then return end
if name == "" then message("FaceMosaic", "Please enter a name.") return end

local job = BASE .. "/jobs/enroll-" .. os.date("%Y%m%d-%H%M%S")
os.execute("mkdir -p " .. q(job))
local cmd = job .. "/run.command"
local f = assert(io.open(cmd, "w"))
f:write(table.concat({
  "#!/bin/bash",
  "clear",
  q(PY) .. " " .. q(ENGINE) .. " enroll " .. q(name) .. " --from-video " .. q(path),
  "echo",
  "read -n 1 -s -r -p 'Press any key to close this window'",
  "",
}, "\n"))
f:close()
os.execute("chmod +x " .. q(cmd) .. " && open -a Terminal " .. q(cmd))
