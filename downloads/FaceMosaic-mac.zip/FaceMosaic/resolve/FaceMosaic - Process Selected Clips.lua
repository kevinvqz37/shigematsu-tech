-- FaceMosaic: mosaic every face in the selected Media Pool clips,
-- except the people you tick. Runs the heavy work in a Terminal window
-- so Resolve stays usable. When it finishes, run "FaceMosaic - Import Results".

local HOME   = os.getenv("HOME")
local BASE   = HOME .. "/FaceMosaic"
local PY     = BASE .. "/venv/bin/python3"
local ENGINE = BASE .. "/app/facemosaic.py"

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local function q(s)
  local r = tostring(s):gsub("'", "'\\''")
  return "'" .. r .. "'"
end

-- Resolve returns selections as {clip=index} or {index=clip} depending on version; accept both.
local function clips_in(t)
  local out = {}
  for k, v in pairs(t or {}) do
    local c = (type(v) == "userdata" or type(v) == "table") and v or ((type(k) == "userdata" or type(k) == "table") and k or nil)
    if c then out[#out + 1] = c end
  end
  return out
end

local function exists(p)
  local f = io.open(p, "r")
  if f then f:close() return true end
  return false
end

local function write_file(p, text)
  local f = assert(io.open(p, "w"))
  f:write(text)
  f:close()
end

local function read_lines(p)
  local t = {}
  local f = io.open(p, "r")
  if not f then return t end
  for line in f:lines() do
    if line ~= "" then t[#t + 1] = line end
  end
  f:close()
  return t
end

local function message(title, text)
  local win = disp:AddWindow({ ID = "FMMsg", WindowTitle = title, Geometry = { 300, 300, 480, 170 } },
    ui:VGroup{
      ui:Label{ Text = text, WordWrap = true },
      ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } },
    })
  function win.On.OK.Clicked(ev) disp:ExitLoop() end
  function win.On.FMMsg.Close(ev) disp:ExitLoop() end
  win:Show(); disp:RunLoop(); win:Hide()
end

-- ---------------------------------------------------------------- checks
if not exists(PY) or not exists(ENGINE) then
  message("FaceMosaic", "FaceMosaic isn't installed yet.\n\nRun install.command from the FaceMosaic folder first.")
  return
end

local project = resolve:GetProjectManager():GetCurrentProject()
if not project then
  message("FaceMosaic", "Open a project first.")
  return
end
local mp = project:GetMediaPool()

-- ---------------------------------------------------------------- license
local BUY_URL = "https://buy.stripe.com/aFa7sL1yV31U5CVg8i9MY02"   -- set by the release build

local function run_engine(args)
  local h = io.popen(q(PY) .. " " .. q(ENGINE) .. " " .. args .. " 2>&1")
  local out = h and h:read("*a") or ""
  if h then h:close() end
  return out
end

local function ensure_license()
  local out = run_engine("license")
  if out:find("STATUS=ok", 1, true) then return true end
  local reason = out:match("STATUS=needed ([^\n]*)") or "FaceMosaic isn't activated on this Mac."
  while true do
    local lw = disp:AddWindow({ ID = "FMLic", WindowTitle = "FaceMosaic — License", Geometry = { 320, 260, 500, 210 } },
      ui:VGroup{
        ui:Label{ ID = "Msg", Text = reason, WordWrap = true, Weight = 0 },
        ui:HGroup{ Weight = 0,
          ui:Label{ Text = "License key:", Weight = 0 },
          ui:LineEdit{ ID = "Key", PlaceholderText = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX" },
        },
        ui:HGroup{ Weight = 0,
          ui:Button{ ID = "Buy", Text = "Buy a license" },
          ui:HGap(0, 1),
          ui:Button{ ID = "Cancel", Text = "Cancel" },
          ui:Button{ ID = "Activate", Text = "Activate" },
        },
      })
    local it = lw:GetItems()
    local choice = nil
    function lw.On.Activate.Clicked(ev) choice = "activate"; disp:ExitLoop() end
    function lw.On.Cancel.Clicked(ev) choice = "cancel"; disp:ExitLoop() end
    function lw.On.Buy.Clicked(ev) os.execute("open " .. q(BUY_URL)) end
    function lw.On.FMLic.Close(ev) choice = "cancel"; disp:ExitLoop() end
    lw:Show(); disp:RunLoop()
    local key = (it.Key.Text or ""):gsub("%s+", "")
    lw:Hide()
    if choice ~= "activate" then return false end
    if key ~= "" then
      local res = run_engine("license --activate " .. q(key))
      if res:find("Activated", 1, true) then
        message("FaceMosaic", res:match("(Activated[^\n]*)") or "Activated.")
        return true
      end
      reason = res:match("STATUS=needed ([^\n]*)") or "Activation failed."
    else
      reason = "Enter your license key."
    end
  end
end

if not ensure_license() then return end

-- ---------------------------------------------------------------- clips
local function read_all(p)
  local f = io.open(p, "r")
  if not f then return nil end
  local s = f:read("*a"); f:close(); return s
end

-- A mosaic clip that has markers named "Keep": un-mosaic the face at each marker and re-render.
-- Returns "source<TAB>folder" so the new version replaces this file, or nil.
local n_keep_marks = 0
local function redo_line(clip, path)
  local rep = read_all((path:gsub("%.mov$", ".json")))
  local src = rep and rep:match('"source"%s*:%s*"(.-)"')
  if not src or not exists(src) then return nil end
  local frames = {}
  local ok, marks = pcall(function() return clip:GetMarkers() end)
  if ok and marks then
    for fr, m in pairs(marks) do
      local label = ((m.name or "") .. " " .. (m.note or "")):lower()
      if label:find("keep") or label:find("unblur") or label:find("show") then
        frames[#frames + 1] = tostring(math.floor(tonumber(fr) or 0))
      end
    end
  end
  table.sort(frames, function(a, b) return tonumber(a) < tonumber(b) end)
  n_keep_marks = n_keep_marks + #frames
  write_file((path:gsub("%.mov$", ".overrides.json")), '{"keep": [' .. table.concat(frames, ", ") .. ']}\n')
  return src .. "\t" .. path:match("^(.*)/[^/]+$")
end

local function is_video(clip)
  local path = clip:GetClipProperty("File Path") or ""
  local typ = clip:GetClipProperty("Type") or ""
  if path == "" or not typ:find("Video") then return nil end
  if path:find("_mosaic%.mov$") then return redo_line(clip, path) end
  return path
end

local paths, seen = {}, {}
local ok, sel = pcall(function() return mp:GetSelectedClips() end)
if ok and sel then
  for _, clip in ipairs(clips_in(sel)) do
    local p = is_video(clip)
    if p and not seen[p] then paths[#paths + 1] = p; seen[p] = true end
  end
end
local source_note
if #paths > 0 then
  source_note = #paths .. " selected clip(s)"
  if n_keep_marks > 0 then
    source_note = source_note .. " — un-mosaicking " .. n_keep_marks .. " spot(s) you marked Keep"
  end
else
  local folder = mp:GetCurrentFolder()
  for _, clip in ipairs(clips_in(folder:GetClipList())) do
    local fp = clip:GetClipProperty("File Path") or ""
    local p = (not fp:find("_mosaic%.mov$")) and is_video(clip) or nil
    if p and not seen[p] then paths[#paths + 1] = p; seen[p] = true end
  end
  source_note = "nothing selected, so ALL " .. #paths .. " video clip(s) in the bin '" .. folder:GetName() .. "'"
end
if #paths == 0 then
  message("FaceMosaic", "No video clips found. Select clips in the Media Pool, then run this again.")
  return
end

-- ---------------------------------------------------------------- people
local people = {}
local pf = io.popen("find " .. q(BASE .. "/people") .. " -mindepth 1 -maxdepth 1 -type d ! -name '.*' 2>/dev/null | sort")
if pf then
  for line in pf:lines() do people[#people + 1] = line:match("([^/]+)$") end
  pf:close()
end

local last = {}
for _, n in ipairs(read_lines(BASE .. "/last_keep.txt")) do last[n] = true end
local has_last = exists(BASE .. "/last_keep.txt")

-- ---------------------------------------------------------------- dialog
local rows = {
  ui:Label{ Text = "Processing " .. source_note .. ".", WordWrap = true, Weight = 0 },
  ui:VGap(6),
}
if #people == 0 then
  rows[#rows + 1] = ui:Label{ WordWrap = true, Weight = 0,
    Text = "<b>No people enrolled yet</b> — every face will be mosaicked, including yours.<br>" ..
           "Use <i>FaceMosaic - Add Person From Selected Clip</i> or <i>Open People Folder</i> first." }
else
  rows[#rows + 1] = ui:Label{ Text = "<b>Keep these people visible</b> (everyone else gets a mosaic):", Weight = 0 }
  for i, name in ipairs(people) do
    rows[#rows + 1] = ui:CheckBox{ ID = "P" .. i, Text = name, Checked = (not has_last) or last[name] == true, Weight = 0 }
  end
end
rows[#rows + 1] = ui:VGap(8)
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:Label{ Text = "Output format:", Weight = 0 },
  ui:ComboBox{ ID = "Codec" },
}
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:Label{ Text = "Matching:", Weight = 0 },
  ui:ComboBox{ ID = "Strict" },
}
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:Label{ Text = "Face search:", Weight = 0 },
  ui:ComboBox{ ID = "Speed" },
}
rows[#rows + 1] = ui:CheckBox{ ID = "Replace", Weight = 0, Checked = false,
  Text = "When importing, swap the originals in my timelines for the mosaic versions" }
rows[#rows + 1] = ui:VGap(0, 1)
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:HGap(0, 1),
  ui:Button{ ID = "Cancel", Text = "Cancel" },
  ui:Button{ ID = "Run", Text = "Start Mosaic" },
}

local height = 290 + 26 * math.max(1, #people)
local win = disp:AddWindow({ ID = "FMMain", WindowTitle = "FaceMosaic", Geometry = { 300, 200, 560, height } },
  ui:VGroup(rows))
local items = win:GetItems()
items.Codec:AddItem("ProRes 422 — best for editing (large files)")
items.Codec:AddItem("HEVC — small files")
items.Codec:AddItem("H.264 — small files, most compatible")
items.Speed:AddItem("Thorough — catches small faces in crowds")
items.Speed:AddItem("Fast — about 40% quicker search, may miss small background faces")
items.Strict:AddItem("Normal")
items.Strict:AddItem("Strict — fewer faces left visible by mistake")
items.Strict:AddItem("Relaxed — if you keep getting mosaicked yourself")

local go = false
function win.On.Run.Clicked(ev) go = true; disp:ExitLoop() end
function win.On.Cancel.Clicked(ev) disp:ExitLoop() end
function win.On.FMMain.Close(ev) disp:ExitLoop() end
win:Show(); disp:RunLoop()

local keep = {}
for i, name in ipairs(people) do
  if items["P" .. i].Checked then keep[#keep + 1] = name end
end
local codec = ({ [0] = "prores", [1] = "hevc", [2] = "h264" })[items.Codec.CurrentIndex] or "prores"
local threshold = ({ [0] = "0.363", [1] = "0.42", [2] = "0.32" })[items.Strict.CurrentIndex] or "0.363"
local replace = items.Replace.Checked
local speed = (items.Speed.CurrentIndex == 1) and "fast" or "thorough"
win:Hide()
if not go then return end

-- ---------------------------------------------------------------- job
local job = BASE .. "/jobs/" .. os.date("%Y%m%d-%H%M%S")
os.execute("mkdir -p " .. q(job))
write_file(job .. "/clips.txt", table.concat(paths, "\n") .. "\n")
write_file(job .. "/keep.txt", table.concat(keep, "\n") .. "\n")
write_file(BASE .. "/last_keep.txt", table.concat(keep, "\n") .. "\n")
write_file(job .. "/options.txt",
  "codec=" .. codec .. "\nthreshold=" .. threshold .. "\nreplace=" .. (replace and "1" or "0") ..
  "\nspeed=" .. speed .. "\nproject=" .. (project:GetName() or "") .. "\n")

local cmd = job .. "/run.command"
write_file(cmd, table.concat({
  "#!/bin/bash",
  "clear",
  "echo 'FaceMosaic — " .. #paths .. " clip(s). You can keep editing in Resolve while this runs.'",
  "caffeinate -i -w $$ &",   -- keep the Mac awake until this window's job ends
  q(PY) .. " " .. q(ENGINE) .. " process --job " .. q(job),
  "status=$?",
  "echo",
  "if [ $status -eq 0 ]; then echo 'All done.'; else echo 'Finished with problems (see above). Finished clips can still be imported.'; fi",
  "echo 'Back in Resolve: Workspace > Scripts > FaceMosaic - Import Results'",
  "osascript -e 'display notification \"Run FaceMosaic - Import Results in Resolve\" with title \"FaceMosaic finished\" sound name \"Glass\"' >/dev/null 2>&1",
  "echo",
  "read -n 1 -s -r -p 'Press any key to close this window'",
  "",
}, "\n"))
os.execute("chmod +x " .. q(cmd) .. " && open -a Terminal " .. q(cmd))
