-- FaceMosaic: show this Mac's license, or move it to another Mac (deactivate here).
local HOME   = os.getenv("HOME")
local BASE   = HOME .. "/FaceMosaic"
local PY     = BASE .. "/venv/bin/python3"
local ENGINE = BASE .. "/app/facemosaic.py"

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local function q(s)
  local r = tostring(s):gsub("'", "'\\''")
  return "'" .. r .. "'"
end

local function run_engine(args)
  local h = io.popen(q(PY) .. " " .. q(ENGINE) .. " " .. args .. " 2>&1")
  local out = h and h:read("*a") or ""
  if h then h:close() end
  return out
end

local status = run_engine("license")
local text
if status:find("STATUS=ok", 1, true) then
  text = "FaceMosaic is activated on this Mac (" .. (status:match("key=(%S+)") or "developer build") .. ").\n\n" ..
         "Moving to a new Mac? Deactivate here first, then activate the same key there."
else
  text = status:match("STATUS=needed ([^\n]*)") or "Not activated."
end

local win = disp:AddWindow({ ID = "FMLicInfo", WindowTitle = "FaceMosaic — License", Geometry = { 320, 260, 480, 190 } },
  ui:VGroup{
    ui:Label{ Text = text, WordWrap = true },
    ui:HGroup{ Weight = 0,
      ui:Button{ ID = "Deactivate", Text = "Deactivate this Mac" },
      ui:HGap(0, 1),
      ui:Button{ ID = "OK", Text = "Close" } },
  })
local deact = false
function win.On.Deactivate.Clicked(ev) deact = true; disp:ExitLoop() end
function win.On.OK.Clicked(ev) disp:ExitLoop() end
function win.On.FMLicInfo.Close(ev) disp:ExitLoop() end
win:Show(); disp:RunLoop(); win:Hide()

if deact then
  local res = run_engine("license --deactivate")
  local msg = res:match("(Deactivated[^\n]*)") or res:match("STATUS=needed ([^\n]*)") or res
  local w2 = disp:AddWindow({ ID = "FMLicDone", WindowTitle = "FaceMosaic — License", Geometry = { 340, 280, 440, 140 } },
    ui:VGroup{ ui:Label{ Text = msg, WordWrap = true },
               ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } } })
  function w2.On.OK.Clicked(ev) disp:ExitLoop() end
  function w2.On.FMLicDone.Close(ev) disp:ExitLoop() end
  w2:Show(); disp:RunLoop(); w2:Hide()
end
