# FaceMosaic for DaVinci Resolve Studio (Mac and Windows)

Mosaics every face in your footage, except the people you choose to keep visible.
It runs from Resolve's **Workspace > Scripts** menu.

## Install (one time)
**Mac (Intel or Apple silicon):**
1. Unzip, open the `FaceMosaic` folder, then right-click **install.command** and choose **Open**.
   macOS asks the first time because the file isn't from the App Store.
   You can also open Terminal and run `bash ~/Downloads/FaceMosaic/install.command`.
2. Restart Resolve.

**Windows 10/11:**
1. Right-click the zip and choose **Extract All**, then open the `FaceMosaic` folder and double-click **install.bat**.
   If Windows shows "Windows protected your PC", click **More info → Run anyway**.
2. Restart Resolve.

The installer puts everything in a `FaceMosaic` folder in your home folder
(`~/FaceMosaic` on Mac, `C:\Users\<you>\FaceMosaic` on Windows). Your original footage is never modified.

## Teach it who to keep visible
Pick either method:
- **From a clip:** select a clip in the Media Pool where you're the biggest face on screen
  (a selfie vlog shot is ideal), then run **FaceMosaic - Add Person From Selected Clip** and type your name.
  It saves about 25 face photos. Open the folder and **delete any photo that isn't you**.
- **From photos:** run **FaceMosaic - Open People Folder**, make a folder named after the person
  (e.g. `Saki`), and drop in 5–15 clear photos. HEIC files from an iPhone work.

Variety helps: different angles, lighting, sunglasses or no sunglasses, a hat, a mask.

## Mosaic your footage
1. Select clips in the Media Pool. If none are selected, it uses every video clip in the current bin.
2. Run **FaceMosaic - Process Selected Clips**, tick the people to keep visible, then click **Start Mosaic**.
3. A Terminal window (Mac) or command window (Windows) shows progress. You can keep editing while it runs.
4. Run **FaceMosaic - Import Results**.
   - By default, the mosaic clips go into a **FaceMosaic** bin.
   - If you ticked *swap the originals*, your existing timelines switch to the mosaic versions automatically.
     Timecode and length match the originals.
     To undo a swap, right-click the clip and choose *Replace Selected Clip…* to pick the original again.

Output files are saved next to each original in a `FaceMosaic/` folder, as `<name>_mosaic.mov`. Audio and timecode are kept.

## Markers: where to take a quick look
- **Red**: a face was left visible, but the match was borderline. Check that it's really you or your family.
- **Yellow**: a face was mosaicked, but it looked a bit like someone you kept. This usually means you, seen side-on or partly out of frame.

If you keep getting mosaicked yourself, add more photos of yourself, or choose **Matching: Relaxed**.
If strangers are being left visible, choose **Strict**.

## Good to know
- **Always scrub through before publishing.** Faces in profile, tiny faces far away, and heavy motion blur are where any detector can miss.
  Any face it detects but can't confidently identify gets mosaicked, so it errs on the side of hiding people.
- **Speed:** each clip is decoded twice, once to find faces and once to write the result. Plan on roughly real time or slower for 4K.
  HEVC and H.264 use the hardware encoder when available (Apple, NVIDIA, Intel or AMD); ProRes is hardware-encoded on Apple silicon.
- **iPhone HDR (HLG/Dolby Vision):** HLG color is preserved, but Dolby Vision dynamic metadata is dropped. The clip grades as normal HLG.
- **Format:** ProRes 422 is best for editing but produces large files. Choose HEVC if disk space is tight.

## Command line (optional)
```
# Mac
~/FaceMosaic/venv/bin/python3 ~/FaceMosaic/app/facemosaic.py process --keep Kevin clip1.mov clip2.mp4
# Windows
%USERPROFILE%\FaceMosaic\venv\Scripts\python.exe %USERPROFILE%\FaceMosaic\app\facemosaic.py people
```

Models: YuNet face detector (MIT) and SFace face recognizer (Apache-2.0), both from OpenCV Zoo.
