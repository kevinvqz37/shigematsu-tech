-- FaceMosaic: small platform layer shared by the Resolve scripts (macOS + Windows).
-- Loaded with dofile() from <home>/FaceMosaic/app/fm_platform.lua.
local P = {}

P.WIN = package.config:sub(1, 1) == "\\"
P.SEP = P.WIN and "\\" or "/"
P.HOME = os.getenv("HOME") or os.getenv("USERPROFILE") or ""
if P.WIN then P.HOME = os.getenv("USERPROFILE") or P.HOME end
P.BASE = P.HOME .. P.SEP .. "FaceMosaic"
P.PY = P.WIN and (P.BASE .. "\\venv\\Scripts\\python.exe") or (P.BASE .. "/venv/bin/python3")
P.ENGINE = P.BASE .. P.SEP .. "app" .. P.SEP .. "facemosaic.py"
P.MACHINE = P.WIN and "PC" or "Mac"

function P.join(...)
  return table.concat({ ... }, P.SEP)
end

-- quote one argument for the shell
function P.q(s)
  s = tostring(s)
  if P.WIN then
    return '"' .. s:gsub('"', '""') .. '"'
  end
  return "'" .. s:gsub("'", "'\\''") .. "'"
end

-- cmd.exe strips the first and last quote of a command line; wrap it once more
local function cmdline(c)
  if P.WIN then return '"' .. c .. '"' end
  return c
end

function P.popen_read(c)
  local h = io.popen(cmdline(c .. " 2>&1"))
  local out = h and h:read("*a") or ""
  if h then h:close() end
  return out
end

function P.run_engine(args)
  return P.popen_read(P.q(P.PY) .. " " .. P.q(P.ENGINE) .. " " .. args)
end

function P.exists(p)
  local f = io.open(p, "r")
  if f then f:close() return true end
  return false
end

function P.mkdir(p)
  if P.WIN then
    os.execute(cmdline("mkdir " .. P.q(p) .. " >nul 2>nul"))
  else
    os.execute("mkdir -p " .. P.q(p))
  end
end

-- open a folder, file or URL with the system's default app
function P.open(target)
  if P.WIN then
    if target:match("^https?://") then
      os.execute(cmdline('start "" ' .. P.q(target)))
    else
      os.execute(cmdline("explorer " .. P.q(target)))
    end
  else
    os.execute("open " .. P.q(target))
  end
end

-- names of the sub-folders of dir (not hidden), sorted
function P.subdirs(dir)
  local out = {}
  local c = P.WIN and ("dir /b /ad " .. P.q(dir)) or ("find " .. P.q(dir) .. " -mindepth 1 -maxdepth 1 -type d")
  local h = io.popen(cmdline(c .. (P.WIN and " 2>nul" or " 2>/dev/null")))
  if h then
    for line in h:lines() do
      local name = line:gsub("\r$", ""):match("([^\\/]+)$")
      if name and name ~= "" and name:sub(1, 1) ~= "." then out[#out + 1] = name end
    end
    h:close()
  end
  table.sort(out)
  return out
end

-- file name and folder of a path (either slash)
function P.basename(p) return (p:match("([^\\/]+)$")) or p end
function P.dirname(p) return (p:match("^(.*)[\\/][^\\/]+$")) or "." end

-- Run a long job in its own console window so Resolve stays usable.
-- lines: shell commands (sh on macOS, cmd on Windows); title: window text.
function P.launch_console(dir, name, lines, title)
  if P.WIN then
    local path = dir .. "\\" .. name .. ".bat"
    local f = assert(io.open(path, "w"))
    f:write("@echo off\r\nchcp 65001 >nul\r\ntitle " .. (title or "FaceMosaic") .. "\r\n")
    f:write(table.concat(lines, "\r\n") .. "\r\n")
    f:write("echo.\r\npause\r\n")
    f:close()
    os.execute(cmdline('start "' .. (title or "FaceMosaic") .. '" cmd /c ' .. P.q(path)))
  else
    local path = dir .. "/" .. name .. ".command"
    local f = assert(io.open(path, "w"))
    f:write("#!/bin/bash\nclear\n" .. table.concat(lines, "\n") .. "\necho\nread -n 1 -s -r -p 'Press any key to close this window'\n")
    f:close()
    os.execute("chmod +x " .. P.q(path) .. " && open -a Terminal " .. P.q(path))
  end
end

-- one line that prints text in the console (no shell metacharacters needed in text)
function P.echo(text)
  if P.WIN then
    if text == "" then return "echo." end
    return "echo " .. text:gsub("[%^&|<>]", "^%0")
  end
  return "echo " .. P.q(text)
end

-- desktop notification when a job ends (best effort)
function P.notify_line(title, text)
  if P.WIN then
    return 'powershell -NoProfile -Command "[console]::beep(880,200)" >nul 2>nul'
  end
  return "osascript -e 'display notification \"" .. text .. "\" with title \"" .. title .. "\" sound name \"Glass\"' >/dev/null 2>&1"
end

-- read a JSON string field, with JSON escapes undone (Windows paths are "C:\\...")
function P.json_string(text, key)
  local v = text and text:match('"' .. key .. '"%s*:%s*"(.-[^\\])"')
  if not v then return nil end
  v = v:gsub("\\u(%x%x%x%x)", function(h) local n = tonumber(h, 16); return n < 128 and string.char(n) or ("\\u" .. h) end)
  v = v:gsub("\\(.)", { ["\\"] = "\\", ['"'] = '"', ["/"] = "/", n = "\n", t = "\t" })
  return v
end

-- ------------------------------------------------------------- UI helpers
P.BUY_URL = "https://buy.stripe.com/aFa7sL1yV31U5CVg8i9MY02"   -- set by the release build

function P.message(ui, disp, title, text)
  local win = disp:AddWindow({ ID = "FMMsg", WindowTitle = title, Geometry = { 300, 300, 480, 180 } },
    ui:VGroup{
      ui:Label{ Text = text, WordWrap = true },
      ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } },
    })
  function win.On.OK.Clicked(ev) disp:ExitLoop() end
  function win.On.FMMsg.Close(ev) disp:ExitLoop() end
  win:Show(); disp:RunLoop(); win:Hide()
end

-- true when this computer holds a valid license (asks for a key if needed)
function P.ensure_license(ui, disp)
  local out = P.run_engine("license")
  if out:find("STATUS=ok", 1, true) then return true end
  local reason = out:match("STATUS=needed ([^\r\n]*)") or ("FaceMosaic isn't activated on this " .. P.MACHINE .. ".")
  while true do
    local lw = disp:AddWindow({ ID = "FMLic", WindowTitle = "FaceMosaic — License", Geometry = { 320, 260, 560, 280 } },
      ui:VGroup{
        ui:Label{ ID = "Msg", Text = reason, WordWrap = true, Weight = 0 },
        ui:Label{ WordWrap = true, Weight = 0,
          Text = "No key yet? <b>Try it free</b>: everything works, but your videos get a small " ..
                 "\"FaceMosaic TRIAL\" mark in the corner. Activate a key any time to get clean versions." },
        ui:HGroup{ Weight = 0,
          ui:Label{ Text = "License key:", Weight = 0 },
          ui:LineEdit{ ID = "Key", PlaceholderText = "FM-…" },
        },
        ui:HGroup{ Weight = 0,
          ui:Button{ ID = "Buy", Text = "Buy a license" },
          ui:HGap(0, 1),
          ui:Button{ ID = "Cancel", Text = "Cancel" },
          ui:Button{ ID = "Trial", Text = "Try free" },
          ui:Button{ ID = "Activate", Text = "Activate" },
        },
      })
    local it = lw:GetItems()
    local choice = nil
    function lw.On.Activate.Clicked(ev) choice = "activate"; disp:ExitLoop() end
    function lw.On.Cancel.Clicked(ev) choice = "cancel"; disp:ExitLoop() end
    function lw.On.Trial.Clicked(ev) choice = "trial"; disp:ExitLoop() end
    function lw.On.Buy.Clicked(ev) P.open(P.BUY_URL) end
    function lw.On.FMLic.Close(ev) choice = "cancel"; disp:ExitLoop() end
    lw:Show(); disp:RunLoop()
    local key = (it.Key.Text or ""):gsub("%s+", "")
    lw:Hide()
    if choice == "trial" then return true end
    if choice ~= "activate" then return false end
    if key ~= "" then
      local res = P.run_engine("license --activate " .. P.q(key))
      if res:find("Activated", 1, true) then
        P.message(ui, disp, "FaceMosaic", res:match("(Activated[^\r\n]*)") or "Activated.")
        return true
      end
      reason = res:match("STATUS=needed ([^\r\n]*)") or "Activation failed."
    else
      reason = "Enter your license key."
    end
  end
end

return P
