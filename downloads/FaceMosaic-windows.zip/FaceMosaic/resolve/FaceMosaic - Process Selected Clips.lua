-- FaceMosaic: mosaic every face in the selected Media Pool clips,
-- except the people you tick. Runs the heavy work in its own console window
-- so Resolve stays usable. When it finishes, run "FaceMosaic - Import Results".
-- Select a finished *_mosaic.mov with markers named "Keep" to un-mosaic those spots and re-render.

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local WIN = package.config:sub(1, 1) == "\\"
local HOMEDIR = (WIN and os.getenv("USERPROFILE")) or os.getenv("HOME") or ""
local okP, P = pcall(dofile, HOMEDIR .. (WIN and "\\FaceMosaic\\app\\fm_platform.lua" or "/FaceMosaic/app/fm_platform.lua"))
if not okP or type(P) ~= "table" then
  local w = disp:AddWindow({ ID = "FMMsg", WindowTitle = "FaceMosaic", Geometry = { 300, 300, 460, 150 } },
    ui:VGroup{ ui:Label{ Text = "FaceMosaic isn't installed yet. Run the installer first, then restart Resolve.", WordWrap = true },
               ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } } })
  function w.On.OK.Clicked(ev) disp:ExitLoop() end
  function w.On.FMMsg.Close(ev) disp:ExitLoop() end
  w:Show(); disp:RunLoop(); w:Hide()
  return
end

local function message(title, text) P.message(ui, disp, title, text) end

-- Resolve returns selections as {clip=index} or {index=clip} depending on version; accept both.
local function clips_in(t)
  local out = {}
  for k, v in pairs(t or {}) do
    local c = (type(v) == "userdata" or type(v) == "table") and v or ((type(k) == "userdata" or type(k) == "table") and k or nil)
    if c then out[#out + 1] = c end
  end
  return out
end

local function write_file(p, text)
  local f = assert(io.open(p, "w"))
  f:write(text)
  f:close()
end

local function read_all(p)
  local f = io.open(p, "r")
  if not f then return nil end
  local s = f:read("*a"); f:close(); return s
end

local function read_lines(p)
  local t = {}
  local f = io.open(p, "r")
  if not f then return t end
  for raw in f:lines() do
    local line = raw:gsub("\r$", "")
    if line ~= "" then t[#t + 1] = line end
  end
  f:close()
  return t
end

-- ---------------------------------------------------------------- checks
if not P.exists(P.PY) or not P.exists(P.ENGINE) then
  message("FaceMosaic", "FaceMosaic isn't installed yet.\n\nRun the installer from the FaceMosaic folder first.")
  return
end

local project = resolve:GetProjectManager():GetCurrentProject()
if not project then
  message("FaceMosaic", "Open a project first.")
  return
end
local mp = project:GetMediaPool()

if not P.ensure_license(ui, disp) then return end

-- ---------------------------------------------------------------- clips
-- A mosaic clip that has markers named "Keep": un-mosaic the face at each marker and re-render.
-- Returns "source<TAB>folder" so the new version replaces this file, or nil.
local n_keep_marks = 0
local function redo_line(clip, path)
  local rep = read_all((path:gsub("%.mov$", ".json")))
  local src = P.json_string(rep, "source")
  if not src or not P.exists(src) then return nil end
  local frames = {}
  local ok, marks = pcall(function() return clip:GetMarkers() end)
  if ok and marks then
    for fr, m in pairs(marks) do
      local label = ((m.name or "") .. " " .. (m.note or "")):lower()
      if label:find("keep") or label:find("unblur") or label:find("show") then
        frames[#frames + 1] = tostring(math.floor(tonumber(fr) or 0))
      end
    end
  end
  table.sort(frames, function(a, b) return tonumber(a) < tonumber(b) end)
  n_keep_marks = n_keep_marks + #frames
  write_file((path:gsub("%.mov$", ".overrides.json")), '{"keep": [' .. table.concat(frames, ", ") .. ']}\n')
  return src .. "\t" .. P.dirname(path)
end

local function is_video(clip, allow_redo)
  local path = clip:GetClipProperty("File Path") or ""
  local typ = clip:GetClipProperty("Type") or ""
  if path == "" or not typ:find("Video") then return nil end
  if path:find("_mosaic%.mov$") then
    return allow_redo and redo_line(clip, path) or nil
  end
  return path
end

local paths, seen = {}, {}
local ok, sel = pcall(function() return mp:GetSelectedClips() end)
if ok and sel then
  for _, clip in ipairs(clips_in(sel)) do
    local p = is_video(clip, true)
    if p and not seen[p] then paths[#paths + 1] = p; seen[p] = true end
  end
end
local source_note
if #paths > 0 then
  source_note = #paths .. " selected clip(s)"
  if n_keep_marks > 0 then
    source_note = source_note .. " — un-mosaicking " .. n_keep_marks .. " spot(s) you marked Keep"
  end
else
  local folder = mp:GetCurrentFolder()
  for _, clip in ipairs(clips_in(folder:GetClipList())) do
    local p = is_video(clip, false)
    if p and not seen[p] then paths[#paths + 1] = p; seen[p] = true end
  end
  source_note = "nothing selected, so ALL " .. #paths .. " video clip(s) in the bin '" .. folder:GetName() .. "'"
end
if #paths == 0 then
  message("FaceMosaic", "No video clips found. Select clips in the Media Pool, then run this again.")
  return
end

-- ---------------------------------------------------------------- people
local people = P.subdirs(P.join(P.BASE, "people"))
local last_path = P.join(P.BASE, "last_keep.txt")
local last = {}
for _, n in ipairs(read_lines(last_path)) do last[n] = true end
local has_last = P.exists(last_path)

-- ---------------------------------------------------------------- dialog
local rows = {
  ui:Label{ Text = "Processing " .. source_note .. ".", WordWrap = true, Weight = 0 },
  ui:VGap(6),
}
if #people == 0 then
  rows[#rows + 1] = ui:Label{ WordWrap = true, Weight = 0,
    Text = "<b>No people enrolled yet</b> — every face will be mosaicked, including yours.<br>" ..
           "Use <i>FaceMosaic - Add Person From Selected Clip</i> or <i>Open People Folder</i> first." }
else
  rows[#rows + 1] = ui:Label{ Text = "<b>Keep these people visible</b> (everyone else gets a mosaic):", Weight = 0 }
  for i, name in ipairs(people) do
    rows[#rows + 1] = ui:CheckBox{ ID = "P" .. i, Text = name, Checked = (not has_last) or last[name] == true, Weight = 0 }
  end
end
rows[#rows + 1] = ui:VGap(8)
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:Label{ Text = "Output format:", Weight = 0 },
  ui:ComboBox{ ID = "Codec" },
}
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:Label{ Text = "Matching:", Weight = 0 },
  ui:ComboBox{ ID = "Strict" },
}
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:Label{ Text = "Face search:", Weight = 0 },
  ui:ComboBox{ ID = "Speed" },
}
rows[#rows + 1] = ui:CheckBox{ ID = "Replace", Weight = 0, Checked = false,
  Text = "When importing, swap the originals in my timelines for the mosaic versions" }
rows[#rows + 1] = ui:VGap(0, 1)
rows[#rows + 1] = ui:HGroup{ Weight = 0,
  ui:HGap(0, 1),
  ui:Button{ ID = "Cancel", Text = "Cancel" },
  ui:Button{ ID = "Run", Text = "Start Mosaic" },
}

local height = 290 + 26 * math.max(1, #people)
local win = disp:AddWindow({ ID = "FMMain", WindowTitle = "FaceMosaic", Geometry = { 300, 200, 560, height } },
  ui:VGroup(rows))
local items = win:GetItems()
items.Codec:AddItem("ProRes 422 — best for editing (large files)")
items.Codec:AddItem("HEVC — small files")
items.Codec:AddItem("H.264 — small files, most compatible")
items.Speed:AddItem("Thorough — catches small faces in crowds")
items.Speed:AddItem("Fast — about 40% quicker search, may miss small background faces")
items.Strict:AddItem("Normal")
items.Strict:AddItem("Strict — fewer faces left visible by mistake")
items.Strict:AddItem("Relaxed — if you keep getting mosaicked yourself")

local go = false
function win.On.Run.Clicked(ev) go = true; disp:ExitLoop() end
function win.On.Cancel.Clicked(ev) disp:ExitLoop() end
function win.On.FMMain.Close(ev) disp:ExitLoop() end
win:Show(); disp:RunLoop()

local keep = {}
for i, name in ipairs(people) do
  if items["P" .. i].Checked then keep[#keep + 1] = name end
end
local codec = ({ [0] = "prores", [1] = "hevc", [2] = "h264" })[items.Codec.CurrentIndex] or "prores"
local threshold = ({ [0] = "0.363", [1] = "0.42", [2] = "0.32" })[items.Strict.CurrentIndex] or "0.363"
local replace = items.Replace.Checked
local speed = (items.Speed.CurrentIndex == 1) and "fast" or "thorough"
win:Hide()
if not go then return end

-- ---------------------------------------------------------------- job
local job = P.join(P.BASE, "jobs", os.date("%Y%m%d-%H%M%S"))
P.mkdir(job)
write_file(P.join(job, "clips.txt"), table.concat(paths, "\n") .. "\n")
write_file(P.join(job, "keep.txt"), table.concat(keep, "\n") .. "\n")
write_file(last_path, table.concat(keep, "\n") .. "\n")
write_file(P.join(job, "options.txt"),
  "codec=" .. codec .. "\nthreshold=" .. threshold .. "\nreplace=" .. (replace and "1" or "0") ..
  "\nspeed=" .. speed .. "\nproject=" .. (project:GetName() or "") .. "\n")

local engine = P.q(P.PY) .. " " .. P.q(P.ENGINE) .. " process --job " .. P.q(job)
local lines
if P.WIN then
  lines = {
    P.echo("FaceMosaic - " .. #paths .. " clip(s). You can keep editing in Resolve while this runs."),
    engine,   -- the engine keeps Windows awake itself while it works
    "if errorlevel 1 (echo Finished with problems, see above. Finished clips can still be imported.) else (echo All done.)",
    P.echo("Back in Resolve: Workspace > Scripts > FaceMosaic - Import Results"),
    P.notify_line("FaceMosaic finished", "Run FaceMosaic - Import Results in Resolve"),
  }
else
  lines = {
    P.echo("FaceMosaic — " .. #paths .. " clip(s). You can keep editing in Resolve while this runs."),
    "caffeinate -i -w $$ &",   -- keep the Mac awake until this window's job ends
    engine,
    "status=$?",
    "echo",
    "if [ $status -eq 0 ]; then echo 'All done.'; else echo 'Finished with problems (see above). Finished clips can still be imported.'; fi",
    P.echo("Back in Resolve: Workspace > Scripts > FaceMosaic - Import Results"),
    P.notify_line("FaceMosaic finished", "Run FaceMosaic - Import Results in Resolve"),
  }
end
P.launch_console(job, "run", lines, "FaceMosaic")
