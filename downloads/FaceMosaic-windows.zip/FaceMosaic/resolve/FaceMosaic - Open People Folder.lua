-- FaceMosaic: open the folder of people kept visible.

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local WIN = package.config:sub(1, 1) == "\\"
local HOMEDIR = (WIN and os.getenv("USERPROFILE")) or os.getenv("HOME") or ""
local okP, P = pcall(dofile, HOMEDIR .. (WIN and "\\FaceMosaic\\app\\fm_platform.lua" or "/FaceMosaic/app/fm_platform.lua"))
if not okP or type(P) ~= "table" then
  local w = disp:AddWindow({ ID = "FMMsg", WindowTitle = "FaceMosaic", Geometry = { 300, 300, 460, 150 } },
    ui:VGroup{ ui:Label{ Text = "FaceMosaic isn't installed yet. Run the installer first, then restart Resolve.", WordWrap = true },
               ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } } })
  function w.On.OK.Clicked(ev) disp:ExitLoop() end
  function w.On.FMMsg.Close(ev) disp:ExitLoop() end
  w:Show(); disp:RunLoop(); w:Hide()
  return
end
-- One sub-folder per person (e.g. "Kevin", "Saki"), each with a few clear photos of their face.
-- Different angles, lighting, glasses/no glasses and hats all help.
local dir = P.join(P.BASE, "people")
P.mkdir(dir)
P.open(dir)
