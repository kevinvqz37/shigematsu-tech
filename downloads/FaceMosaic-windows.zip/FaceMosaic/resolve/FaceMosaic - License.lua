-- FaceMosaic: show this computer's license, or move it to another computer (deactivate here).

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local WIN = package.config:sub(1, 1) == "\\"
local HOMEDIR = (WIN and os.getenv("USERPROFILE")) or os.getenv("HOME") or ""
local okP, P = pcall(dofile, HOMEDIR .. (WIN and "\\FaceMosaic\\app\\fm_platform.lua" or "/FaceMosaic/app/fm_platform.lua"))
if not okP or type(P) ~= "table" then
  local w = disp:AddWindow({ ID = "FMMsg", WindowTitle = "FaceMosaic", Geometry = { 300, 300, 460, 150 } },
    ui:VGroup{ ui:Label{ Text = "FaceMosaic isn't installed yet. Run the installer first, then restart Resolve.", WordWrap = true },
               ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } } })
  function w.On.OK.Clicked(ev) disp:ExitLoop() end
  function w.On.FMMsg.Close(ev) disp:ExitLoop() end
  w:Show(); disp:RunLoop(); w:Hide()
  return
end

local status = P.run_engine("license")
local text
if status:find("STATUS=ok", 1, true) then
  text = "FaceMosaic is activated on this " .. P.MACHINE .. " (" .. (status:match("key=(%S+)") or "developer build") .. ").\n\n" ..
         "Moving to a new computer? Deactivate here first, then activate the same key there."
else
  text = status:match("STATUS=needed ([^\r\n]*)") or "Not activated."
end

local win = disp:AddWindow({ ID = "FMLicInfo", WindowTitle = "FaceMosaic — License", Geometry = { 320, 260, 500, 190 } },
  ui:VGroup{
    ui:Label{ Text = text, WordWrap = true },
    ui:HGroup{ Weight = 0,
      ui:Button{ ID = "Deactivate", Text = "Deactivate this " .. P.MACHINE },
      ui:HGap(0, 1),
      ui:Button{ ID = "OK", Text = "Close" } },
  })
local deact = false
function win.On.Deactivate.Clicked(ev) deact = true; disp:ExitLoop() end
function win.On.OK.Clicked(ev) disp:ExitLoop() end
function win.On.FMLicInfo.Close(ev) disp:ExitLoop() end
win:Show(); disp:RunLoop(); win:Hide()

if deact then
  local res = P.run_engine("license --deactivate")
  local msg = res:match("(Deactivated[^\r\n]*)") or res:match("STATUS=needed ([^\r\n]*)") or res
  P.message(ui, disp, "FaceMosaic — License", msg)
end
