-- FaceMosaic: teach it a face to keep visible.
-- Select ONE clip where that person is the biggest face on screen (a selfie vlog shot is perfect),
-- enter their name, and it saves ~25 face photos into <home>/FaceMosaic/people/<Name>/.
-- Check that folder afterwards and delete any photo that isn't them.

local resolve = resolve or Resolve()
local fu = fu or fusion or resolve:Fusion()
local ui = fu.UIManager
local disp = bmd.UIDispatcher(ui)

local WIN = package.config:sub(1, 1) == "\\"
local HOMEDIR = (WIN and os.getenv("USERPROFILE")) or os.getenv("HOME") or ""
local okP, P = pcall(dofile, HOMEDIR .. (WIN and "\\FaceMosaic\\app\\fm_platform.lua" or "/FaceMosaic/app/fm_platform.lua"))
if not okP or type(P) ~= "table" then
  local w = disp:AddWindow({ ID = "FMMsg", WindowTitle = "FaceMosaic", Geometry = { 300, 300, 460, 150 } },
    ui:VGroup{ ui:Label{ Text = "FaceMosaic isn't installed yet. Run the installer first, then restart Resolve.", WordWrap = true },
               ui:HGroup{ Weight = 0, ui:HGap(0, 1), ui:Button{ ID = "OK", Text = "OK" } } })
  function w.On.OK.Clicked(ev) disp:ExitLoop() end
  function w.On.FMMsg.Close(ev) disp:ExitLoop() end
  w:Show(); disp:RunLoop(); w:Hide()
  return
end

-- Resolve returns selections as {clip=index} or {index=clip} depending on version; accept both.
local function clips_in(t)
  local out = {}
  for k, v in pairs(t or {}) do
    local c = (type(v) == "userdata" or type(v) == "table") and v or ((type(k) == "userdata" or type(k) == "table") and k or nil)
    if c then out[#out + 1] = c end
  end
  return out
end

local function message(title, text) P.message(ui, disp, title, text) end

if not P.exists(P.PY) or not P.exists(P.ENGINE) then
  message("FaceMosaic", "FaceMosaic isn't installed yet. Run the installer first.")
  return
end
local project = resolve:GetProjectManager():GetCurrentProject()
if not project then message("FaceMosaic", "Open a project first.") return end
local mp = project:GetMediaPool()

if not P.ensure_license(ui, disp) then return end

local path
local ok, sel = pcall(function() return mp:GetSelectedClips() end)
if ok and sel then
  for _, clip in ipairs(clips_in(sel)) do
    local p = clip:GetClipProperty("File Path") or ""
    local t = clip:GetClipProperty("Type") or ""
    if p ~= "" and t:find("Video") then path = p break end
  end
end
if not path then
  message("FaceMosaic", "Select one video clip in the Media Pool where the person's face is big and clear, then run this again.")
  return
end

local win = disp:AddWindow({ ID = "FMAdd", WindowTitle = "FaceMosaic — Add Person", Geometry = { 300, 250, 460, 170 } },
  ui:VGroup{
    ui:Label{ Text = "From: " .. P.basename(path), WordWrap = true, Weight = 0 },
    ui:HGroup{ Weight = 0,
      ui:Label{ Text = "Name:", Weight = 0 },
      ui:LineEdit{ ID = "Name", PlaceholderText = "e.g. Kevin" },
    },
    ui:Label{ Text = "The biggest face in the clip is used. You'll check the photos afterwards.", WordWrap = true, Weight = 0 },
    ui:HGroup{ Weight = 0, ui:HGap(0, 1),
      ui:Button{ ID = "Cancel", Text = "Cancel" },
      ui:Button{ ID = "Go", Text = "Add" } },
  })
local items = win:GetItems()
local go = false
function win.On.Go.Clicked(ev) go = true; disp:ExitLoop() end
function win.On.Cancel.Clicked(ev) disp:ExitLoop() end
function win.On.FMAdd.Close(ev) disp:ExitLoop() end
win:Show(); disp:RunLoop()
local name = (items.Name.Text or ""):gsub("[/\\:\"'`$<>|?*%%^&]", ""):gsub("^%s+", ""):gsub("%s+$", "")
win:Hide()
if not go then return end
if name == "" then message("FaceMosaic", "Please enter a name.") return end

local job = P.join(P.BASE, "jobs", "enroll-" .. os.date("%Y%m%d-%H%M%S"))
P.mkdir(job)
P.launch_console(job, "run", {
  P.q(P.PY) .. " " .. P.q(P.ENGINE) .. " enroll " .. P.q(name) .. " --from-video " .. P.q(path),
}, "FaceMosaic - Add Person")
