# FaceMosaic installer for Windows + DaVinci Resolve Studio.
# Run install.bat (double-click). It calls this script.
$ErrorActionPreference = "Continue"   # native tools write progress to stderr; failures are checked explicitly
$ProgressPreference = "SilentlyContinue"   # makes Invoke-WebRequest much faster
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-Location -LiteralPath $PSScriptRoot

$Dest = Join-Path $env:USERPROFILE "FaceMosaic"
$ResolveScripts = Join-Path $env:APPDATA "Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility"

function Fail($msg) {
  Write-Host ""
  Write-Host $msg -ForegroundColor Red
  Read-Host "Press Enter to close"
  exit 1
}

Write-Host "Installing FaceMosaic into $Dest"
Write-Host ""
New-Item -ItemType Directory -Force -Path $Dest, (Join-Path $Dest "people"), (Join-Path $Dest "jobs") | Out-Null

# 1. Python. Release builds ship a pinned Python (the compiled engine needs that exact version).
$Py = $null
$UrlFile = Join-Path $PSScriptRoot "app\PYTHON_URL_windows"
if (Test-Path $UrlFile) {
  $PyUrl = (Get-Content $UrlFile -Raw).Trim()
  $PyDir = Join-Path $Dest "python"
  $Stamp = Join-Path $PyDir ".source"
  $have = (Test-Path (Join-Path $PyDir "python.exe")) -and (Test-Path $Stamp) -and ((Get-Content $Stamp -Raw).Trim() -eq $PyUrl)
  if (-not $have) {
    Write-Host "Downloading Python runtime (one time, about 30 MB)..."
    if (Test-Path $PyDir) { Remove-Item -Recurse -Force $PyDir }
    $tgz = Join-Path $Dest "python.tar.gz"
    try { Invoke-WebRequest -Uri $PyUrl -OutFile $tgz -UseBasicParsing -ErrorAction Stop } catch { Fail "Download failed. Check your internet connection and run the installer again." }
    tar -xzf $tgz -C $Dest
    if ($LASTEXITCODE -ne 0) { Fail "Couldn't unpack the Python runtime." }
    Remove-Item $tgz
    Set-Content -Path $Stamp -Value $PyUrl
    if (Test-Path (Join-Path $Dest "venv")) { Remove-Item -Recurse -Force (Join-Path $Dest "venv") }
  }
  $Py = Join-Path $PyDir "python.exe"
} else {
  foreach ($c in @("py", "python")) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $Py = $cmd.Source; break }
  }
  if (-not $Py) { Fail "Python 3 is needed. Install it from python.org, then run this installer again." }
}
Write-Host ("Using " + (& $Py --version) + " at $Py")

# 2. files (keep already-downloaded models when updating)
$App = Join-Path $Dest "app"
$Keep = Join-Path $Dest ".models-keep"
if (Test-Path (Join-Path $App "models")) {
  if (Test-Path $Keep) { Remove-Item -Recurse -Force $Keep }
  Move-Item (Join-Path $App "models") $Keep
}
if (Test-Path $App) { Remove-Item -Recurse -Force $App }
Copy-Item -Recurse (Join-Path $PSScriptRoot "app") $App
if (Test-Path $Keep) { Move-Item $Keep (Join-Path $App "models") }
Get-ChildItem -Recurse $App | Unblock-File -ErrorAction SilentlyContinue

# models (downloaded once from OpenCV Zoo)
$Models = Join-Path $App "models"
New-Item -ItemType Directory -Force -Path $Models | Out-Null
function Get-Model($name, $zooPath, $minBytes, $hfRepo) {
  $f = Join-Path $Models $name
  if ((Test-Path $f) -and ((Get-Item $f).Length -ge $minBytes)) { return }
  Write-Host "Downloading $name ..."
  foreach ($url in @("https://media.githubusercontent.com/media/opencv/opencv_zoo/main/$zooPath",
                     "https://huggingface.co/opencv/$hfRepo/resolve/main/$name")) {
    try {
      Invoke-WebRequest -Uri $url -OutFile "$f.part" -UseBasicParsing -ErrorAction Stop
      if ((Get-Item "$f.part").Length -ge $minBytes) { Move-Item -Force "$f.part" $f; return }
    } catch { }
  }
  if (Test-Path "$f.part") { Remove-Item "$f.part" }
  Fail "Could not download $name. Check your internet connection and run the installer again."
}
Get-Model "face_detection_yunet_2023mar.onnx" "models/face_detection_yunet/face_detection_yunet_2023mar.onnx" 200000 "face_detection_yunet"
Get-Model "face_recognition_sface_2021dec.onnx" "models/face_recognition_sface/face_recognition_sface_2021dec.onnx" 30000000 "face_recognition_sface"

# 3. private Python environment with OpenCV + ffmpeg
$VPy = Join-Path $Dest "venv\Scripts\python.exe"
if (-not (Test-Path $VPy)) {
  & $Py -m venv (Join-Path $Dest "venv")
  if ($LASTEXITCODE -ne 0) { Fail "Couldn't create the Python environment." }
}
& $VPy -m pip install --quiet --disable-pip-version-check --upgrade pip
& $VPy -m pip install --quiet --disable-pip-version-check -r (Join-Path $PSScriptRoot "requirements.txt")
if ($LASTEXITCODE -ne 0) { Fail "Installing Python packages failed. Check your internet connection and run the installer again." }
Write-Host "Python packages installed."

# 4. Resolve menu scripts (Workspace > Scripts)
New-Item -ItemType Directory -Force -Path $ResolveScripts | Out-Null
Get-ChildItem $ResolveScripts -Filter "FaceMosaic - *.lua" -ErrorAction SilentlyContinue | Remove-Item -Force
Copy-Item (Join-Path $PSScriptRoot "resolve\*.lua") $ResolveScripts
Write-Host "Resolve scripts installed."

# 5. self-test
& $VPy (Join-Path $App "facemosaic.py") people
if ($LASTEXITCODE -ne 0) { Fail "The self-test failed. Please send a screenshot of this window to support." }

Write-Host ""
Write-Host "Done. Restart DaVinci Resolve, then look under Workspace > Scripts for:" -ForegroundColor Green
Write-Host "  - FaceMosaic - Add Person From Selected Clip"
Write-Host "  - FaceMosaic - Open People Folder"
Write-Host "  - FaceMosaic - Process Selected Clips"
Write-Host "  - FaceMosaic - Import Results"
Write-Host "  - FaceMosaic - License"
Write-Host ""
Read-Host "Press Enter to close"
